package com.example.chat1104.utilities;
import android.content.Context;
import android.content.SharedPreferences;

// Create preferenceManager
public class preferenceManager {

    //Initialize sharedPreferences
    private final SharedPreferences sharedPreferences;

    //Create constructor
    public preferenceManager(Context context) {
        sharedPreferences = context.getSharedPreferences(Constants.KEY_PREFERENCE_NAME, Context.MODE_PRIVATE);

    }
    //Create putBoolean
    public void putBoolean(String key, Boolean value){
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(key, value);
        editor.apply();
    }
    //Create getBoolean
    public Boolean getBoolean(String key){
        return sharedPreferences.getBoolean(key, false);
    }

    //Create putString & getString
    public void putString(String key, String value){
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(key, value);
        editor.apply();
    }
    public String getString(String key){
        return sharedPreferences.getString(key, null);
    }

    //Create clear
    public void clear(){
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.clear();
            editor.apply();
        }
}
